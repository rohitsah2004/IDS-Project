import React from 'react';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { useSimulation } from '../../context/SimulationContext';

ChartJS.register(
  ArcElement,
  Tooltip,
  Legend
);

const ProtocolDistribution: React.FC = () => {
  const { trafficStats } = useSimulation();
  
  const colors = [
    'rgba(59, 130, 246, 0.7)',  // Blue
    'rgba(16, 185, 129, 0.7)',  // Green
    'rgba(245, 158, 11, 0.7)',  // Amber
    'rgba(239, 68, 68, 0.7)',   // Red
    'rgba(139, 92, 246, 0.7)',  // Purple
    'rgba(236, 72, 153, 0.7)',  // Pink
    'rgba(20, 184, 166, 0.7)',  // Teal
  ];
  
  const borderColors = [
    'rgb(59, 130, 246)',
    'rgb(16, 185, 129)',
    'rgb(245, 158, 11)',
    'rgb(239, 68, 68)',
    'rgb(139, 92, 246)',
    'rgb(236, 72, 153)',
    'rgb(20, 184, 166)',
  ];
  
  const chartData = {
    labels: Object.keys(trafficStats.protocolDistribution),
    datasets: [
      {
        data: Object.values(trafficStats.protocolDistribution),
        backgroundColor: colors.slice(0, Object.keys(trafficStats.protocolDistribution).length),
        borderColor: borderColors.slice(0, Object.keys(trafficStats.protocolDistribution).length),
        borderWidth: 1,
      },
    ],
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          color: 'rgba(255, 255, 255, 0.7)',
          padding: 10,
          usePointStyle: true,
          pointStyle: 'circle',
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.raw || 0;
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = Math.round((value * 100) / total) + '%';
            return `${label}: ${value} (${percentage})`;
          }
        }
      }
    },
  };
  
  if (Object.keys(trafficStats.protocolDistribution).length === 0) {
    return (
      <div className="h-60 flex items-center justify-center">
        <p className="text-gray-400">No protocol data available</p>
      </div>
    );
  }

  return (
    <div className="h-60">
      <Doughnut data={chartData} options={options} />
    </div>
  );
};

export default ProtocolDistribution;