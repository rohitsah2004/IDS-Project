import React, { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useSimulation } from '../../context/SimulationContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const TrafficChart: React.FC = () => {
  const { traffic, isRunning } = useSimulation();
  const [chartData, setChartData] = useState({
    labels: [] as string[],
    datasets: [
      {
        label: 'Packets',
        data: [] as number[],
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4,
      },
    ],
  });

  useEffect(() => {
    // Update the chart data when traffic changes
    const updateChartData = () => {
      const now = Date.now();
      const oneMinuteAgo = now - 60000;
      
      // Group traffic by time (10 second intervals)
      const timeIntervals: { [key: string]: number } = {};
      const interval = 2000; // 2 second intervals
      
      // Create intervals
      for (let time = oneMinuteAgo; time <= now; time += interval) {
        const label = new Date(time).toLocaleTimeString([], { 
          hour: '2-digit', 
          minute: '2-digit', 
          second: '2-digit' 
        });
        timeIntervals[label] = 0;
      }
      
      // Count packets in each interval
      traffic.forEach(packet => {
        if (packet.timestamp >= oneMinuteAgo) {
          const intervalTime = Math.floor(packet.timestamp / interval) * interval;
          const label = new Date(intervalTime).toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
          });
          if (timeIntervals[label] !== undefined) {
            timeIntervals[label]++;
          }
        }
      });
      
      const labels = Object.keys(timeIntervals);
      const data = Object.values(timeIntervals);
      
      setChartData({
        labels,
        datasets: [
          {
            label: 'Packets',
            data,
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            fill: true,
            tension: 0.4,
          },
        ],
      });
    };
    
    updateChartData();
    
    // Set up interval to update chart data regularly if simulation is running
    const interval = isRunning ? setInterval(updateChartData, 2000) : null;
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [traffic, isRunning]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(255, 255, 255, 0.1)',
        },
        ticks: {
          color: 'rgba(255, 255, 255, 0.7)',
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: 'rgba(255, 255, 255, 0.7)',
          maxRotation: 45,
          minRotation: 45,
        },
      },
    },
    plugins: {
      legend: {
        display: true,
        labels: {
          color: 'rgba(255, 255, 255, 0.7)',
        },
      },
      tooltip: {
        mode: 'index',
        intersect: false,
      },
    },
    animation: {
      duration: 500,
    },
  };

  return (
    <div className="h-60">
      <Line data={chartData} options={options} />
    </div>
  );
};

export default TrafficChart;