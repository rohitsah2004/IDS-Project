import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Bell, User, Play, Pause } from 'lucide-react';

const Header: React.FC = () => {
  const { isRunning, startSimulation, stopSimulation, alerts } = useSimulation();
  const [isOpen, setIsOpen] = useState(false);
  
  const recentAlerts = alerts.slice(0, 5);
  const unreadCount = recentAlerts.filter(alert => !alert.read).length;

  return (
    <header className="bg-gray-800 border-b border-gray-700 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center">
        <h1 className="text-xl font-semibold hidden md:block">Network Intrusion Detection System</h1>
      </div>
      
      <div className="flex items-center">
        <button
          onClick={() => isRunning ? stopSimulation() : startSimulation()}
          className={`mr-4 px-3 py-1 rounded-md flex items-center ${
            isRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
          } text-white transition-colors`}
        >
          {isRunning ? <Pause size={16} className="mr-1" /> : <Play size={16} className="mr-1" />}
          {isRunning ? 'Stop' : 'Start'} Monitoring
        </button>
        
        <div className="relative mr-2">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded-full hover:bg-gray-700 relative"
          >
            <Bell size={20} />
            {unreadCount > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-xs text-white rounded-full w-4 h-4 flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>
          
          {isOpen && (
            <div className="absolute right-0 mt-2 w-72 bg-gray-800 border border-gray-700 rounded-md shadow-lg z-10">
              <div className="p-3 border-b border-gray-700">
                <h3 className="font-medium">Recent Alerts</h3>
              </div>
              <div className="max-h-64 overflow-y-auto">
                {recentAlerts.length > 0 ? (
                  recentAlerts.map((alert) => (
                    <div key={alert.id} className="p-3 border-b border-gray-700 hover:bg-gray-700">
                      <div className="flex items-start">
                        <div className={`w-2 h-2 rounded-full mt-1.5 mr-2 ${
                          alert.severity === 'high' ? 'bg-red-500' : 
                          alert.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                        }`} />
                        <div>
                          <p className="font-medium text-sm">{alert.type}</p>
                          <p className="text-xs text-gray-400">{alert.sourceIp} → {alert.destinationIp}</p>
                          <p className="text-xs text-gray-500 mt-1">{new Date(alert.timestamp).toLocaleTimeString()}</p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="p-3 text-gray-500 text-sm">No recent alerts</p>
                )}
              </div>
              <div className="p-2 border-t border-gray-700">
                <button className="w-full text-center text-sm text-blue-400 hover:text-blue-300 py-1">
                  View All Alerts
                </button>
              </div>
            </div>
          )}
        </div>
        
        <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
          <User size={16} />
        </div>
      </div>
    </header>
  );
};

export default Header;