import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  AlertTriangle, 
  Network, 
  FileSearch, 
  Settings,
  Shield,
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const location = useLocation();
  
  const navItems = [
    { name: 'Dashboard', path: '/', icon: <LayoutDashboard size={18} /> },
    { name: 'Alerts', path: '/alerts', icon: <AlertTriangle size={18} /> },
    { name: 'Traffic', path: '/traffic', icon: <Network size={18} /> },
    { name: 'Packet Analysis', path: '/packet-analysis', icon: <FileSearch size={18} /> },
    { name: 'Settings', path: '/settings', icon: <Settings size={18} /> },
  ];

  return (
    <aside className="w-full md:w-64 bg-gray-800 border-r border-gray-700 md:min-h-screen">
      <div className="p-4 flex items-center justify-center md:justify-start">
        <Shield className="h-8 w-8 text-blue-500" />
        <span className="ml-2 text-xl font-bold text-white">NIDS</span>
      </div>
      <nav className="mt-6">
        <ul>
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center px-4 py-3 text-sm transition-colors duration-200 ${
                  location.pathname === item.path
                    ? 'bg-gray-700 text-blue-400 border-l-4 border-blue-500'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-gray-100'
                }`}
              >
                <span className="w-6">{item.icon}</span>
                <span className="ml-2">{item.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;