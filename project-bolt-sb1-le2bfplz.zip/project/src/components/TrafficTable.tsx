import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Traffic } from '../types';

interface TrafficTableProps {
  limit?: number;
}

const TrafficTable: React.FC<TrafficTableProps> = ({ limit }) => {
  const { traffic } = useSimulation();
  
  // Sort traffic by timestamp (most recent first) and apply limit if provided
  const displayedTraffic = [...traffic]
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit || traffic.length);
  
  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
  };
  
  if (displayedTraffic.length === 0) {
    return (
      <div className="p-6 text-center">
        <p className="text-gray-400">No traffic data yet</p>
      </div>
    );
  }
  
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-800">
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Protocol</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Source</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Destination</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Size</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Time</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-700">
          {displayedTraffic.map((packet: Traffic) => (
            <tr key={packet.id} className="hover:bg-gray-700">
              <td className="p-3 whitespace-nowrap">
                <span className={`px-2 py-1 text-xs rounded-full ${
                  packet.protocol === 'TCP' ? 'bg-blue-900/50 text-blue-200' :
                  packet.protocol === 'UDP' ? 'bg-green-900/50 text-green-200' :
                  packet.protocol === 'ICMP' ? 'bg-red-900/50 text-red-200' :
                  packet.protocol === 'HTTP' ? 'bg-purple-900/50 text-purple-200' :
                  packet.protocol === 'HTTPS' ? 'bg-teal-900/50 text-teal-200' :
                  packet.protocol === 'DNS' ? 'bg-amber-900/50 text-amber-200' :
                  'bg-gray-900/50 text-gray-200'
                }`}>
                  {packet.protocol}
                </span>
              </td>
              <td className="p-3 whitespace-nowrap text-sm">
                {packet.sourceIp}:{packet.sourcePort}
              </td>
              <td className="p-3 whitespace-nowrap text-sm">
                {packet.destinationIp}:{packet.destinationPort}
              </td>
              <td className="p-3 whitespace-nowrap text-sm">
                {packet.size} bytes
              </td>
              <td className="p-3 whitespace-nowrap text-sm">
                {formatTimestamp(packet.timestamp)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TrafficTable;