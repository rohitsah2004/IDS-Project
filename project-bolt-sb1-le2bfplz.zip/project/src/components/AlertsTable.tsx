import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Alert } from '../types';
import { AlertTriangle, Shield, AlertCircle } from 'lucide-react';

interface AlertsTableProps {
  limit?: number;
  showActions?: boolean;
}

const AlertsTable: React.FC<AlertsTableProps> = ({ limit, showActions = true }) => {
  const { alerts, markAlertAsRead } = useSimulation();
  
  // Sort alerts by timestamp (most recent first) and apply limit if provided
  const displayedAlerts = [...alerts]
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit || alerts.length);
  
  const handleMarkAsRead = (id: string) => {
    markAlertAsRead(id);
  };
  
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertCircle size={18} className="text-red-500" />;
      case 'medium':
        return <AlertTriangle size={18} className="text-amber-500" />;
      case 'low':
        return <Shield size={18} className="text-blue-500" />;
      default:
        return <AlertTriangle size={18} className="text-gray-500" />;
    }
  };
  
  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };
  
  if (displayedAlerts.length === 0) {
    return (
      <div className="p-6 text-center">
        <p className="text-gray-400">No alerts yet</p>
      </div>
    );
  }
  
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-800">
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Severity</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Type</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Source IP</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Destination IP</th>
            <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Timestamp</th>
            {showActions && (
              <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
            )}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-700">
          {displayedAlerts.map((alert: Alert) => (
            <tr 
              key={alert.id} 
              className={`hover:bg-gray-700 ${!alert.read ? 'bg-gray-800/50' : ''}`}
            >
              <td className="p-3 whitespace-nowrap">
                <div className="flex items-center">
                  {getSeverityIcon(alert.severity)}
                  <span className="ml-2 capitalize text-sm">
                    {alert.severity}
                  </span>
                </div>
              </td>
              <td className="p-3 whitespace-nowrap">
                <div className="text-sm font-medium">{alert.type}</div>
                <div className="text-xs text-gray-400">{alert.description}</div>
              </td>
              <td className="p-3 whitespace-nowrap text-sm">{alert.sourceIp}</td>
              <td className="p-3 whitespace-nowrap text-sm">{alert.destinationIp}</td>
              <td className="p-3 whitespace-nowrap text-sm">{formatTimestamp(alert.timestamp)}</td>
              {showActions && (
                <td className="p-3 whitespace-nowrap text-sm">
                  {!alert.read && (
                    <button 
                      onClick={() => handleMarkAsRead(alert.id)}
                      className="text-blue-400 hover:text-blue-300 text-xs"
                    >
                      Mark as read
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AlertsTable;