export interface Alert {
  id: string;
  type: string;
  description: string;
  sourceIp: string;
  destinationIp: string;
  timestamp: number;
  severity: 'low' | 'medium' | 'high';
  read: boolean;
  details?: {
    [key: string]: any;
  };
}

export interface Traffic {
  id: string;
  sourceIp: string;
  destinationIp: string;
  sourcePort: number;
  destinationPort: number;
  protocol: string;
  size: number;
  timestamp: number;
}

export interface TrafficStats {
  totalPackets: number;
  bytesTransferred: number;
  protocolDistribution: {
    [key: string]: number;
  };
  topSources: {
    ip: string;
    count: number;
  }[];
  topDestinations: {
    ip: string;
    count: number;
  }[];
}

export interface GeoLocation {
  ip: string;
  country: string;
  city: string;
  latitude: number;
  longitude: number;
}

export interface PacketDetails {
  id: string;
  timestamp: number;
  sourceIp: string;
  destinationIp: string;
  sourcePort: number;
  destinationPort: number;
  protocol: string;
  size: number;
  flags?: string[];
  ttl?: number;
  payload?: string;
  headers?: {
    [key: string]: any;
  };
}