import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  generateTraffic, 
  generateAlert, 
  simulatePortScan,
  simulateDDoS,
  simulateDataExfiltration,
  generatePacketDetails
} from '../utils/simulationData';
import { Alert, Traffic, TrafficStats, PacketDetails } from '../types';

interface SimulationContextType {
  isRunning: boolean;
  startSimulation: () => void;
  stopSimulation: () => void;
  alerts: Alert[];
  traffic: Traffic[];
  trafficStats: TrafficStats;
  packetDetails: PacketDetails[];
  markAlertAsRead: (id: string) => void;
  clearAllAlerts: () => void;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const useSimulation = (): SimulationContextType => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};

interface SimulationProviderProps {
  children: React.ReactNode;
}

export const SimulationProvider: React.FC<SimulationProviderProps> = ({ children }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [traffic, setTraffic] = useState<Traffic[]>([]);
  const [packetDetails, setPacketDetails] = useState<PacketDetails[]>([]);
  const [trafficStats, setTrafficStats] = useState<TrafficStats>({
    totalPackets: 0,
    bytesTransferred: 0,
    protocolDistribution: {},
    topSources: [],
    topDestinations: [],
  });
  
  // Count packets per IP for stats
  const updateTrafficStats = useCallback((newTraffic: Traffic[]) => {
    setTrafficStats(prev => {
      // Create counters
      const protocolCount: { [key: string]: number } = { ...prev.protocolDistribution };
      const sourceCount: { [key: string]: number } = {};
      const destCount: { [key: string]: number } = {};
      
      // Process existing and new traffic
      const allTraffic = [...traffic.slice(-500), ...newTraffic];
      
      // Update counters
      allTraffic.forEach(packet => {
        // Update protocol distribution
        protocolCount[packet.protocol] = (protocolCount[packet.protocol] || 0) + 1;
        
        // Update source and destination counts
        sourceCount[packet.sourceIp] = (sourceCount[packet.sourceIp] || 0) + 1;
        destCount[packet.destinationIp] = (destCount[packet.destinationIp] || 0) + 1;
      });
      
      // Convert to arrays and sort for top lists
      const topSources = Object.entries(sourceCount)
        .map(([ip, count]) => ({ ip, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);
      
      const topDestinations = Object.entries(destCount)
        .map(([ip, count]) => ({ ip, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);
      
      return {
        totalPackets: prev.totalPackets + newTraffic.length,
        bytesTransferred: prev.bytesTransferred + newTraffic.reduce((sum, packet) => sum + packet.size, 0),
        protocolDistribution: protocolCount,
        topSources,
        topDestinations,
      };
    });
  }, [traffic]);
  
  // Generate normal traffic
  const generateNormalTraffic = useCallback(() => {
    if (!isRunning) return;
    
    // Create 2-5 packets in each batch
    const packetCount = Math.floor(Math.random() * 4) + 2;
    const newTraffic: Traffic[] = [];
    
    for (let i = 0; i < packetCount; i++) {
      const trafficPacket = generateTraffic();
      newTraffic.push(trafficPacket);
      
      // Generate packet details for each traffic entry
      const details = generatePacketDetails(trafficPacket);
      setPacketDetails(prev => [...prev.slice(-100), details]);
    }
    
    setTraffic(prev => [...prev.slice(-1000), ...newTraffic]);
    updateTrafficStats(newTraffic);
    
    // Schedule next batch
    const delay = Math.floor(Math.random() * 1500) + 500; // 0.5-2 seconds
    setTimeout(generateNormalTraffic, delay);
  }, [isRunning, updateTrafficStats]);
  
  // Simulate attack patterns occasionally
  const simulateAttacks = useCallback(() => {
    if (!isRunning) return;
    
    const attackType = Math.floor(Math.random() * 10);
    const targetIp = '192.168.1.10'; // Example internal IP as target
    let attackTraffic: Traffic[] = [];
    let newAlert: Alert | null = null;
    
    if (attackType < 3) { // 30% chance of port scan
      attackTraffic = simulatePortScan(targetIp);
      newAlert = {
        id: Math.random().toString(36).substring(2, 11),
        type: 'Port Scan',
        description: 'Multiple connection attempts to different ports detected',
        sourceIp: attackTraffic[0].sourceIp,
        destinationIp: targetIp,
        timestamp: Date.now(),
        severity: 'medium',
        read: false,
      };
    } else if (attackType < 5) { // 20% chance of DDoS
      attackTraffic = simulateDDoS(targetIp);
      newAlert = {
        id: Math.random().toString(36).substring(2, 11),
        type: 'DDoS Attack',
        description: 'Unusually high traffic volume from multiple sources',
        sourceIp: 'Multiple',
        destinationIp: targetIp,
        timestamp: Date.now(),
        severity: 'high',
        read: false,
      };
    } else if (attackType < 7) { // 20% chance of data exfiltration
      attackTraffic = simulateDataExfiltration('192.168.1.100');
      newAlert = {
        id: Math.random().toString(36).substring(2, 11),
        type: 'Data Exfiltration',
        description: 'Large data transfer to external IP',
        sourceIp: '192.168.1.100',
        destinationIp: attackTraffic[0].destinationIp,
        timestamp: Date.now(),
        severity: 'high',
        read: false,
      };
    } else if (attackType < 9) { // 20% chance of other alert without special traffic
      newAlert = generateAlert();
    }
    
    if (attackTraffic.length > 0) {
      setTraffic(prev => [...prev.slice(-1000), ...attackTraffic]);
      updateTrafficStats(attackTraffic);
      
      // Generate packet details for attack traffic
      const newPacketDetails = attackTraffic.map(packet => generatePacketDetails(packet));
      setPacketDetails(prev => [...prev.slice(-100), ...newPacketDetails]);
    }
    
    if (newAlert) {
      setAlerts(prev => [...prev.slice(-100), newAlert!]);
    }
    
    // Schedule next attack simulation
    const nextAttackTime = Math.floor(Math.random() * 30000) + 15000; // 15-45 seconds
    setTimeout(simulateAttacks, nextAttackTime);
  }, [isRunning, updateTrafficStats]);
  
  const startSimulation = useCallback(() => {
    setIsRunning(true);
  }, []);
  
  const stopSimulation = useCallback(() => {
    setIsRunning(false);
  }, []);
  
  // Start traffic and attack simulations when isRunning changes
  useEffect(() => {
    if (isRunning) {
      generateNormalTraffic();
      simulateAttacks();
    }
  }, [isRunning, generateNormalTraffic, simulateAttacks]);
  
  const markAlertAsRead = useCallback((id: string) => {
    setAlerts(prevAlerts =>
      prevAlerts.map(alert =>
        alert.id === id ? { ...alert, read: true } : alert
      )
    );
  }, []);
  
  const clearAllAlerts = useCallback(() => {
    setAlerts([]);
  }, []);
  
  return (
    <SimulationContext.Provider
      value={{
        isRunning,
        startSimulation,
        stopSimulation,
        alerts,
        traffic,
        trafficStats,
        packetDetails,
        markAlertAsRead,
        clearAllAlerts,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};