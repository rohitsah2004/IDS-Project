import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Alerts from './pages/Alerts';
import Traffic from './pages/Traffic';
import PacketAnalysis from './pages/PacketAnalysis';
import Settings from './pages/Settings';
import { SimulationProvider } from './context/SimulationContext';

function App() {
  return (
    <SimulationProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/traffic" element={<Traffic />} />
          <Route path="/packet-analysis" element={<PacketAnalysis />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
    </SimulationProvider>
  );
}

export default App;