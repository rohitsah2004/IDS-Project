import { Alert, Traffic, GeoLocation, PacketDetails } from '../types';

// Common ports and their services
const commonPorts: { [key: number]: string } = {
  20: 'FTP Data',
  21: 'FTP Control',
  22: 'SSH',
  23: 'Telnet',
  25: 'SMTP',
  53: 'DNS',
  80: 'HTTP',
  110: 'POP3',
  123: 'NTP',
  143: 'IMAP',
  443: 'HTTPS',
  445: 'SMB',
  3306: 'MySQL',
  3389: 'RDP',
  5432: 'PostgreSQL',
  8080: 'HTTP Alternative',
  8443: 'HTTPS Alternative',
};

// IP address generation
export const generateRandomIp = (): string => {
  return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
};

// Common internal network addresses
const internalIps = [
  '192.168.1.1', '192.168.1.2', '192.168.1.10', '192.168.1.100',
  '10.0.0.1', '10.0.0.2', '10.0.0.10', '10.0.0.100',
  '172.16.0.1', '172.16.0.2', '172.16.0.10', '172.16.0.100',
];

// Predefined external IP addresses
const externalIps = [
  '203.0.113.1', '203.0.113.10', '198.51.100.1', '198.51.100.10',
  '8.8.8.8', '8.8.4.4', '1.1.1.1', '9.9.9.9',
  '93.184.216.34', '104.18.2.22', '104.18.3.22',
];

// Some suspicious IPs for attack simulation
const suspiciousIps = [
  '45.227.253.83', '185.180.143.81', '192.241.200.7', '58.218.66.92',
  '91.240.118.168', '45.155.205.108', '198.98.57.28', '103.43.12.106',
];

// GeoIP data for visualization
export const geoIpData: { [key: string]: GeoLocation } = {
  '8.8.8.8': { ip: '8.8.8.8', country: 'United States', city: 'Mountain View', latitude: 37.386, longitude: -122.0838 },
  '1.1.1.1': { ip: '1.1.1.1', country: 'Australia', city: 'Sydney', latitude: -33.8688, longitude: 151.2093 },
  '93.184.216.34': { ip: '93.184.216.34', country: 'United States', city: 'Norwell', latitude: 42.1584, longitude: -70.8294 },
  '104.18.2.22': { ip: '104.18.2.22', country: 'United States', city: 'San Francisco', latitude: 37.7749, longitude: -122.4194 },
  '104.18.3.22': { ip: '104.18.3.22', country: 'United States', city: 'San Francisco', latitude: 37.7749, longitude: -122.4194 },
  '45.227.253.83': { ip: '45.227.253.83', country: 'Brazil', city: 'Sao Paulo', latitude: -23.5505, longitude: -46.6333 },
  '185.180.143.81': { ip: '185.180.143.81', country: 'Netherlands', city: 'Amsterdam', latitude: 52.3676, longitude: 4.9041 },
  '192.241.200.7': { ip: '192.241.200.7', country: 'United States', city: 'New York', latitude: 40.7128, longitude: -74.006 },
  '58.218.66.92': { ip: '58.218.66.92', country: 'China', city: 'Beijing', latitude: 39.9042, longitude: 116.4074 },
  '91.240.118.168': { ip: '91.240.118.168', country: 'Russia', city: 'Moscow', latitude: 55.7558, longitude: 37.6173 },
  '45.155.205.108': { ip: '45.155.205.108', country: 'Turkey', city: 'Istanbul', latitude: 41.0082, longitude: 28.9784 },
  '198.98.57.28': { ip: '198.98.57.28', country: 'Canada', city: 'Toronto', latitude: 43.6532, longitude: -79.3832 },
  '103.43.12.106': { ip: '103.43.12.106', country: 'India', city: 'Mumbai', latitude: 19.076, longitude: 72.8777 },
};

// Common protocols
const protocols = ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS', 'DNS', 'SMTP'];

// Generate random port number
export const generateRandomPort = (): number => {
  return Math.floor(Math.random() * 65535) + 1;
};

// Generate a random port or use a common one based on probability
export const generatePort = (useCommon = true): number => {
  if (useCommon && Math.random() < 0.7) {
    const commonPortList = Object.keys(commonPorts).map(Number);
    return commonPortList[Math.floor(Math.random() * commonPortList.length)];
  }
  return generateRandomPort();
};

// Get port service name if it's a common port
export const getServiceName = (port: number): string => {
  return commonPorts[port] || 'Unknown';
};

// Generate random packet size
export const generatePacketSize = (): number => {
  return Math.floor(Math.random() * 1460) + 40; // 40-1500 bytes (typical packet size range)
};

// Generate realistic traffic patterns
export const generateTraffic = (): Traffic => {
  const useInternal = Math.random() < 0.6; // 60% chance of internal source
  const useExternal = Math.random() < 0.8; // 80% chance of external destination
  
  const sourceIp = useInternal
    ? internalIps[Math.floor(Math.random() * internalIps.length)]
    : externalIps[Math.floor(Math.random() * externalIps.length)];
  
  const destinationIp = useExternal
    ? externalIps[Math.floor(Math.random() * externalIps.length)]
    : internalIps[Math.floor(Math.random() * internalIps.length)];
  
  const protocol = protocols[Math.floor(Math.random() * protocols.length)];
  const isCommonProtocol = protocol === 'HTTP' || protocol === 'HTTPS' || protocol === 'DNS';
  
  return {
    id: Math.random().toString(36).substring(2, 11),
    sourceIp,
    destinationIp,
    sourcePort: generatePort(!isCommonProtocol),
    destinationPort: isCommonProtocol
      ? (protocol === 'HTTP' ? 80 : protocol === 'HTTPS' ? 443 : 53)
      : generatePort(),
    protocol,
    size: generatePacketSize(),
    timestamp: Date.now(),
  };
};

// Alert types
const alertTypes = [
  { type: 'Port Scan', severity: 'medium', description: 'Multiple connection attempts to different ports detected' },
  { type: 'Brute Force', severity: 'high', description: 'Multiple failed login attempts detected' },
  { type: 'DDoS Attack', severity: 'high', description: 'Unusually high traffic volume from multiple sources' },
  { type: 'Malware Communication', severity: 'high', description: 'Communication with known malicious IP address' },
  { type: 'Suspicious Login', severity: 'medium', description: 'Login from unusual geographic location' },
  { type: 'Data Exfiltration', severity: 'high', description: 'Large data transfer to external IP' },
  { type: 'Unknown Protocol', severity: 'low', description: 'Traffic using unrecognized protocol' },
  { type: 'Policy Violation', severity: 'low', description: 'Access to restricted website category' },
  { type: 'Abnormal Behavior', severity: 'medium', description: 'Unusual traffic pattern for this host' },
];

// Generate an alert
export const generateAlert = (): Alert => {
  const alertInfo = alertTypes[Math.floor(Math.random() * alertTypes.length)];
  const useSuspiciousIp = Math.random() < 0.8; // 80% chance of using a suspicious IP
  
  const sourceIp = useSuspiciousIp
    ? suspiciousIps[Math.floor(Math.random() * suspiciousIps.length)]
    : generateRandomIp();
  
  return {
    id: Math.random().toString(36).substring(2, 11),
    type: alertInfo.type,
    description: alertInfo.description,
    sourceIp,
    destinationIp: internalIps[Math.floor(Math.random() * internalIps.length)],
    timestamp: Date.now(),
    severity: alertInfo.severity as 'low' | 'medium' | 'high',
    read: false,
  };
};

// Generate detailed packet information
export const generatePacketDetails = (traffic: Traffic): PacketDetails => {
  const tcpFlags = ['SYN', 'ACK', 'FIN', 'RST', 'PSH', 'URG'];
  const selectedFlags: string[] = [];
  
  if (traffic.protocol === 'TCP') {
    // Generate realistic TCP flag combinations
    if (Math.random() < 0.4) {
      selectedFlags.push('SYN'); // New connection
    } else if (Math.random() < 0.7) {
      selectedFlags.push('ACK'); // Established connection
      if (Math.random() < 0.3) selectedFlags.push('PSH'); // Push data
    } else {
      if (Math.random() < 0.5) {
        selectedFlags.push('FIN'); // Graceful close
        if (Math.random() < 0.7) selectedFlags.push('ACK');
      } else {
        selectedFlags.push('RST'); // Forceful close
      }
    }
  }
  
  return {
    ...traffic,
    flags: traffic.protocol === 'TCP' ? selectedFlags : undefined,
    ttl: Math.floor(Math.random() * 128) + 32, // Typical TTL values
    headers: {
      length: traffic.size,
      checksum: '0x' + Math.floor(Math.random() * 65536).toString(16),
    },
  };
};

// Simulate port scan attack pattern
export const simulatePortScan = (targetIp: string): Traffic[] => {
  const result: Traffic[] = [];
  const sourceIp = suspiciousIps[Math.floor(Math.random() * suspiciousIps.length)];
  const sourcePort = generatePort();
  const now = Date.now();
  
  // Generate connections to multiple sequential ports
  for (let i = 0; i < 15; i++) {
    result.push({
      id: Math.random().toString(36).substring(2, 11),
      sourceIp,
      destinationIp: targetIp,
      sourcePort,
      destinationPort: 20 + i, // Sequential ports starting from 20
      protocol: 'TCP',
      size: 60, // Typical SYN packet size
      timestamp: now + (i * 50), // Slight time difference between packets
    });
  }
  
  return result;
};

// Simulate DDoS attack pattern
export const simulateDDoS = (targetIp: string): Traffic[] => {
  const result: Traffic[] = [];
  const now = Date.now();
  
  // Generate high volume of traffic from multiple sources
  for (let i = 0; i < 30; i++) {
    result.push({
      id: Math.random().toString(36).substring(2, 11),
      sourceIp: generateRandomIp(), // Random source IPs
      destinationIp: targetIp,
      sourcePort: generatePort(),
      destinationPort: 80, // Usually target web servers
      protocol: Math.random() < 0.7 ? 'TCP' : 'UDP',
      size: generatePacketSize(),
      timestamp: now + (i * 20), // Very small time difference
    });
  }
  
  return result;
};

// Simulate data exfiltration
export const simulateDataExfiltration = (sourceIp: string): Traffic[] => {
  const result: Traffic[] = [];
  const destinationIp = suspiciousIps[Math.floor(Math.random() * suspiciousIps.length)];
  const now = Date.now();
  
  // Generate several large packets to suspicious destination
  for (let i = 0; i < 5; i++) {
    result.push({
      id: Math.random().toString(36).substring(2, 11),
      sourceIp,
      destinationIp,
      sourcePort: generatePort(),
      destinationPort: generatePort(false), // Often uses uncommon ports
      protocol: Math.random() < 0.5 ? 'TCP' : 'HTTPS', // Often encrypted
      size: 1400 + Math.floor(Math.random() * 100), // Large packets
      timestamp: now + (i * 200),
    });
  }
  
  return result;
};