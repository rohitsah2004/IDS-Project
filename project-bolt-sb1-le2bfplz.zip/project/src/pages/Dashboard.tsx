import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import TrafficChart from '../components/charts/TrafficChart';
import ProtocolDistribution from '../components/charts/ProtocolDistribution';
import AlertsTable from '../components/AlertsTable';
import StatisticCard from '../components/StatisticCard';
import { 
  Activity, 
  Shield, 
  AlertTriangle, 
  Server,
  Globe,
  Network
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const { trafficStats, alerts, isRunning } = useSimulation();
  
  // Calculate high severity alert count
  const highSeverityCount = alerts.filter(alert => alert.severity === 'high').length;
  
  // Format bytes to human-readable format
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <div className="flex items-center">
          <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
          <span className="ml-2 text-sm font-medium">{isRunning ? 'Monitoring Active' : 'Monitoring Inactive'}</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatisticCard
          title="Total Traffic"
          value={trafficStats.totalPackets.toLocaleString()}
          icon={<Activity size={24} />}
          color="blue"
        />
        <StatisticCard
          title="Data Transferred"
          value={formatBytes(trafficStats.bytesTransferred)}
          icon={<Network size={24} />}
          color="green"
        />
        <StatisticCard
          title="Active Alerts"
          value={alerts.length}
          icon={<AlertTriangle size={24} />}
          color="amber"
        />
        <StatisticCard
          title="High Severity"
          value={highSeverityCount}
          icon={<Shield size={24} />}
          color="red"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Traffic Overview</h2>
          </div>
          <TrafficChart />
        </div>
        
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Protocol Distribution</h2>
          </div>
          <ProtocolDistribution />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Top Source IPs</h2>
          </div>
          <div className="space-y-2">
            {trafficStats.topSources.slice(0, 5).map((source, index) => (
              <div key={source.ip} className="flex items-center">
                <div className="w-8 text-gray-500 text-sm">{index + 1}.</div>
                <div className="flex-1">
                  <div className="flex items-center">
                    <Globe size={14} className="mr-2 text-blue-400" />
                    <span className="text-sm">{source.ip}</span>
                  </div>
                </div>
                <div className="text-sm font-medium">{source.count} packets</div>
              </div>
            ))}
            {trafficStats.topSources.length === 0 && (
              <p className="text-gray-400 text-sm">No data available</p>
            )}
          </div>
        </div>
        
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Top Destination IPs</h2>
          </div>
          <div className="space-y-2">
            {trafficStats.topDestinations.slice(0, 5).map((dest, index) => (
              <div key={dest.ip} className="flex items-center">
                <div className="w-8 text-gray-500 text-sm">{index + 1}.</div>
                <div className="flex-1">
                  <div className="flex items-center">
                    <Server size={14} className="mr-2 text-green-400" />
                    <span className="text-sm">{dest.ip}</span>
                  </div>
                </div>
                <div className="text-sm font-medium">{dest.count} packets</div>
              </div>
            ))}
            {trafficStats.topDestinations.length === 0 && (
              <p className="text-gray-400 text-sm">No data available</p>
            )}
          </div>
        </div>
      </div>
      
      <div className="card">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Recent Alerts</h2>
          <a href="/alerts" className="text-sm text-blue-400 hover:text-blue-300">View All</a>
        </div>
        <AlertsTable limit={5} showActions={false} />
      </div>
    </div>
  );
};

export default Dashboard;