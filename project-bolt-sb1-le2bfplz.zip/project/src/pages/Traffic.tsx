import React from 'react';
import TrafficTable from '../components/TrafficTable';
import { useSimulation } from '../context/SimulationContext';
import TrafficChart from '../components/charts/TrafficChart';
import ProtocolDistribution from '../components/charts/ProtocolDistribution';
import { Network, ArrowDownUp } from 'lucide-react';

const Traffic: React.FC = () => {
  const { trafficStats } = useSimulation();
  
  // Format bytes to human-readable format
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Network Traffic</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="card">
          <div className="flex items-center mb-4">
            <div className="rounded-full h-10 w-10 flex items-center justify-center bg-blue-900/50 text-blue-500">
              <Network size={20} />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-gray-400">Total Packets</h3>
              <p className="text-xl font-semibold">{trafficStats.totalPackets.toLocaleString()}</p>
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center mb-4">
            <div className="rounded-full h-10 w-10 flex items-center justify-center bg-green-900/50 text-green-500">
              <ArrowDownUp size={20} />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-gray-400">Data Transferred</h3>
              <p className="text-xl font-semibold">{formatBytes(trafficStats.bytesTransferred)}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Traffic Over Time</h2>
          </div>
          <TrafficChart />
        </div>
        
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium">Protocol Distribution</h2>
          </div>
          <ProtocolDistribution />
        </div>
      </div>
      
      <div className="card overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Recent Network Traffic</h2>
        </div>
        <TrafficTable limit={20} />
      </div>
    </div>
  );
};

export default Traffic;