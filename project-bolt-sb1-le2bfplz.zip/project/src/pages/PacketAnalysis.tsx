import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { PacketDetails } from '../types';
import { FileSearch, Maximize2, Minimize2 } from 'lucide-react';

const PacketAnalysis: React.FC = () => {
  const { packetDetails } = useSimulation();
  const [selectedPacket, setSelectedPacket] = useState<PacketDetails | null>(null);
  const [expandedView, setExpandedView] = useState(false);
  
  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };
  
  const handleSelectPacket = (packet: PacketDetails) => {
    setSelectedPacket(packet);
  };
  
  const toggleExpandedView = () => {
    setExpandedView(!expandedView);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Packet Analysis</h1>
        <button
          onClick={toggleExpandedView}
          className="btn btn-primary text-sm flex items-center"
        >
          {expandedView ? (
            <>
              <Minimize2 size={16} className="mr-1" />
              Collapse View
            </>
          ) : (
            <>
              <Maximize2 size={16} className="mr-1" />
              Expand View
            </>
          )}
        </button>
      </div>
      
      <div className={`grid ${expandedView ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'} gap-6`}>
        <div className="card overflow-hidden">
          <div className="flex items-center mb-4">
            <FileSearch size={20} className="text-blue-500 mr-2" />
            <h2 className="text-lg font-medium">Packet List</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-800">
                  <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Time</th>
                  <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Protocol</th>
                  <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Source</th>
                  <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Destination</th>
                  <th className="p-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Size</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {packetDetails.length > 0 ? (
                  packetDetails.map((packet) => (
                    <tr 
                      key={packet.id} 
                      className={`hover:bg-gray-700 cursor-pointer ${selectedPacket?.id === packet.id ? 'bg-blue-900/30' : ''}`}
                      onClick={() => handleSelectPacket(packet)}
                    >
                      <td className="p-3 whitespace-nowrap text-sm">
                        {formatTimestamp(packet.timestamp)}
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          packet.protocol === 'TCP' ? 'bg-blue-900/50 text-blue-200' :
                          packet.protocol === 'UDP' ? 'bg-green-900/50 text-green-200' :
                          packet.protocol === 'ICMP' ? 'bg-red-900/50 text-red-200' :
                          packet.protocol === 'HTTP' ? 'bg-purple-900/50 text-purple-200' :
                          packet.protocol === 'HTTPS' ? 'bg-teal-900/50 text-teal-200' :
                          packet.protocol === 'DNS' ? 'bg-amber-900/50 text-amber-200' :
                          'bg-gray-900/50 text-gray-200'
                        }`}>
                          {packet.protocol}
                        </span>
                      </td>
                      <td className="p-3 whitespace-nowrap text-sm">
                        {packet.sourceIp}:{packet.sourcePort}
                      </td>
                      <td className="p-3 whitespace-nowrap text-sm">
                        {packet.destinationIp}:{packet.destinationPort}
                      </td>
                      <td className="p-3 whitespace-nowrap text-sm">
                        {packet.size} bytes
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-gray-400">
                      No packet data available yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
        
        {(!expandedView || selectedPacket) && (
          <div className="card">
            <h2 className="text-lg font-medium mb-4">Packet Details</h2>
            
            {selectedPacket ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-1">Basic Information</h3>
                    <div className="bg-gray-900 rounded-md p-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Timestamp:</span>
                        <span className="text-sm">{formatTimestamp(selectedPacket.timestamp)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Protocol:</span>
                        <span className="text-sm">{selectedPacket.protocol}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Size:</span>
                        <span className="text-sm">{selectedPacket.size} bytes</span>
                      </div>
                      {selectedPacket.ttl && (
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-400">TTL:</span>
                          <span className="text-sm">{selectedPacket.ttl}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-1">Connection</h3>
                    <div className="bg-gray-900 rounded-md p-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Source IP:</span>
                        <span className="text-sm">{selectedPacket.sourceIp}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Source Port:</span>
                        <span className="text-sm">{selectedPacket.sourcePort}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Destination IP:</span>
                        <span className="text-sm">{selectedPacket.destinationIp}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-400">Destination Port:</span>
                        <span className="text-sm">{selectedPacket.destinationPort}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {selectedPacket.flags && selectedPacket.flags.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-1">TCP Flags</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedPacket.flags.map((flag) => (
                        <span 
                          key={flag} 
                          className="px-2 py-1 bg-blue-900/30 text-blue-200 text-xs rounded"
                        >
                          {flag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                
                {selectedPacket.headers && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-1">Headers</h3>
                    <div className="bg-gray-900 rounded-md p-3 overflow-x-auto">
                      <pre className="text-xs text-gray-300">
                        {JSON.stringify(selectedPacket.headers, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-6 text-center">
                <p className="text-gray-400">Select a packet to view details</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PacketAnalysis;