import React, { useState } from 'react';
import AlertsTable from '../components/AlertsTable';
import { useSimulation } from '../context/SimulationContext';
import { AlertTriangle, Shield, AlertCircle, Filter } from 'lucide-react';

const Alerts: React.FC = () => {
  const { alerts, clearAllAlerts } = useSimulation();
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  
  const highSeverityCount = alerts.filter(alert => alert.severity === 'high').length;
  const mediumSeverityCount = alerts.filter(alert => alert.severity === 'medium').length;
  const lowSeverityCount = alerts.filter(alert => alert.severity === 'low').length;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Security Alerts</h1>
        <button
          onClick={clearAllAlerts}
          className="btn btn-danger text-sm"
          disabled={alerts.length === 0}
        >
          Clear All Alerts
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div 
          className={`card cursor-pointer ${severityFilter === 'high' ? 'ring-2 ring-red-500' : ''}`}
          onClick={() => setSeverityFilter(severityFilter === 'high' ? 'all' : 'high')}
        >
          <div className="flex items-center">
            <div className="rounded-full h-12 w-12 flex items-center justify-center bg-red-900/50 text-red-500">
              <AlertCircle size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-400">High Severity</h3>
              <p className="text-2xl font-semibold">{highSeverityCount}</p>
            </div>
          </div>
        </div>
        
        <div 
          className={`card cursor-pointer ${severityFilter === 'medium' ? 'ring-2 ring-amber-500' : ''}`}
          onClick={() => setSeverityFilter(severityFilter === 'medium' ? 'all' : 'medium')}
        >
          <div className="flex items-center">
            <div className="rounded-full h-12 w-12 flex items-center justify-center bg-amber-900/50 text-amber-500">
              <AlertTriangle size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-400">Medium Severity</h3>
              <p className="text-2xl font-semibold">{mediumSeverityCount}</p>
            </div>
          </div>
        </div>
        
        <div 
          className={`card cursor-pointer ${severityFilter === 'low' ? 'ring-2 ring-blue-500' : ''}`}
          onClick={() => setSeverityFilter(severityFilter === 'low' ? 'all' : 'low')}
        >
          <div className="flex items-center">
            <div className="rounded-full h-12 w-12 flex items-center justify-center bg-blue-900/50 text-blue-500">
              <Shield size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-400">Low Severity</h3>
              <p className="text-2xl font-semibold">{lowSeverityCount}</p>
            </div>
          </div>
        </div>
      </div>
      
      {severityFilter !== 'all' && (
        <div className="flex justify-between items-center bg-gray-800 p-3 rounded-lg">
          <div className="flex items-center">
            <Filter size={16} className="text-gray-400 mr-2" />
            <span className="text-sm font-medium">
              Filtering: <span className="capitalize">{severityFilter}</span> Severity Alerts
            </span>
          </div>
          <button 
            onClick={() => setSeverityFilter('all')}
            className="text-sm text-blue-400 hover:text-blue-300"
          >
            Clear Filter
          </button>
        </div>
      )}
      
      <div className="card overflow-hidden">
        <AlertsTable />
      </div>
    </div>
  );
};

export default Alerts;