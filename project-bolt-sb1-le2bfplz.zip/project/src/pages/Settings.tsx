import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Settings as SettingsIcon, Save, Check } from 'lucide-react';

const Settings: React.FC = () => {
  const { isRunning, startSimulation, stopSimulation } = useSimulation();
  const [emailNotifications, setEmailNotifications] = useState(false);
  const [emailAddress, setEmailAddress] = useState('');
  const [highSeverityOnly, setHighSeverityOnly] = useState(true);
  const [savedSuccessfully, setSavedSuccessfully] = useState(false);
  
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate saving settings
    setSavedSuccessfully(true);
    
    setTimeout(() => {
      setSavedSuccessfully(false);
    }, 3000);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Settings</h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center mb-6">
              <SettingsIcon size={20} className="text-blue-500 mr-2" />
              <h2 className="text-lg font-medium">System Configuration</h2>
            </div>
            
            <form onSubmit={handleSaveSettings}>
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Monitoring</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Monitoring Status</span>
                      <button
                        type="button"
                        onClick={() => isRunning ? stopSimulation() : startSimulation()}
                        className={`px-3 py-1 rounded-full text-sm ${
                          isRunning 
                            ? 'bg-green-900/50 text-green-200' 
                            : 'bg-red-900/50 text-red-200'
                        }`}
                      >
                        {isRunning ? 'Active' : 'Inactive'}
                      </button>
                    </div>
                    
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => isRunning ? stopSimulation() : startSimulation()}
                        className={`px-4 py-2 rounded-md text-white ${
                          isRunning
                            ? 'bg-red-600 hover:bg-red-700'
                            : 'bg-green-600 hover:bg-green-700'
                        }`}
                      >
                        {isRunning ? 'Stop Monitoring' : 'Start Monitoring'}
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-gray-700 pt-6">
                  <h3 className="text-sm font-medium text-gray-400 mb-3">Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <input
                        id="email-notifications"
                        type="checkbox"
                        className="h-4 w-4 rounded border-gray-600 text-blue-600 focus:ring-blue-500"
                        checked={emailNotifications}
                        onChange={() => setEmailNotifications(!emailNotifications)}
                      />
                      <label htmlFor="email-notifications" className="ml-2 text-sm">
                        Email Notifications
                      </label>
                    </div>
                    
                    {emailNotifications && (
                      <div className="ml-6 space-y-4">
                        <div>
                          <label htmlFor="email" className="block text-sm text-gray-400 mb-1">
                            Email Address
                          </label>
                          <input
                            type="email"
                            id="email"
                            className="w-full rounded-md bg-gray-700 border-gray-600 text-white focus:ring-blue-500 focus:border-blue-500"
                            value={emailAddress}
                            onChange={(e) => setEmailAddress(e.target.value)}
                            placeholder="your@email.com"
                          />
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            id="high-severity"
                            type="checkbox"
                            className="h-4 w-4 rounded border-gray-600 text-blue-600 focus:ring-blue-500"
                            checked={highSeverityOnly}
                            onChange={() => setHighSeverityOnly(!highSeverityOnly)}
                          />
                          <label htmlFor="high-severity" className="ml-2 text-sm">
                            Only for High Severity Alerts
                          </label>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="border-t border-gray-700 pt-6">
                  <h3 className="text-sm font-medium text-gray-400 mb-3">System</h3>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="log-retention" className="block text-sm text-gray-400 mb-1">
                        Log Retention (days)
                      </label>
                      <select
                        id="log-retention"
                        className="w-full rounded-md bg-gray-700 border-gray-600 text-white focus:ring-blue-500 focus:border-blue-500"
                        defaultValue="30"
                      >
                        <option value="7">7 days</option>
                        <option value="14">14 days</option>
                        <option value="30">30 days</option>
                        <option value="90">90 days</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end pt-4">
                  <button
                    type="submit"
                    className="btn btn-primary flex items-center"
                  >
                    {savedSuccessfully ? (
                      <>
                        <Check size={16} className="mr-1" />
                        Saved
                      </>
                    ) : (
                      <>
                        <Save size={16} className="mr-1" />
                        Save Settings
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
        
        <div>
          <div className="card">
            <h2 className="text-lg font-medium mb-4">System Information</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-2">Version</h3>
                <p className="text-sm">NIDS v1.0.0</p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-2">Status</h3>
                <div className="flex items-center">
                  <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <span className="ml-2 text-sm">{isRunning ? 'Running' : 'Stopped'}</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-2">Documentation</h3>
                <div className="space-y-2">
                  <a href="#" className="text-sm text-blue-400 hover:text-blue-300 block">
                    User Guide
                  </a>
                  <a href="#" className="text-sm text-blue-400 hover:text-blue-300 block">
                    API Documentation
                  </a>
                  <a href="#" className="text-sm text-blue-400 hover:text-blue-300 block">
                    Troubleshooting
                  </a>
                </div>
              </div>
              
              <div className="pt-4">
                <button className="w-full btn btn-primary">
                  Check for Updates
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;